using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

public class Phrase { public string category; public string text; public string offset; }
public class OriginalControl { public string text; public int x,y,w,h; }
public class Catalog { public List<OriginalControl> original_layout; public List<Phrase> phrases; public List<string> random; public string source_sha256; public List<List<string>> insult_groups; public List<List<string>> noise_groups; }
public static class Generators {
    public static string Generate(List<List<string>> groups, Random random, string separator) {
        if(groups==null || groups.Count!=4 || groups.Any(g=>g==null || g.Count==0))
            throw new InvalidDataException("Original generator data is missing. Restore phrases.json from this build.");
        return string.Join(separator,groups.Select(g=>g[random.Next(g.Count)]));
    }
    public static string Insult(Catalog c,Random random) {return Generate(c.insult_groups,random," ");}
    public static string SickoNoise(Catalog c,Random random) {return Generate(c.noise_groups,random,"");}
}
public class Preferences { public string[] boxes = new string[5]; public string[] buttons = new string[16]; }

sealed class OriginalVoice : IDisposable {
    Process process;
    IntPtr window;
    readonly string root;
    public OriginalVoice(string root) { this.root = root; }
    delegate bool EnumProc(IntPtr hwnd, IntPtr param);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc callback, IntPtr param);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll")] static extern IntPtr GetDlgItem(IntPtr hwnd, int id);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern IntPtr SendMessageTimeout(IntPtr hwnd, uint msg, IntPtr wp, string lp, uint flags, uint timeout, out IntPtr result);
    [DllImport("user32.dll")] static extern bool PostMessage(IntPtr hwnd, uint msg, IntPtr wp, IntPtr lp);
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hwnd, int command);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hwnd);
    public async Task Ready() {
        if (process != null && !process.HasExited && IsWindow(window)) return;
        Dispose();
        var runtime = Path.Combine(root, "runtime", "otvdm-v0.9.0", "otvdmw.exe");
        var app = Path.Combine(root, "app");
        if (!File.Exists(runtime) || !File.Exists(Path.Combine(app,"DOC.EXE"))) throw new IOException("Missing original speech engine or compatibility runtime. Keep the entire ShitTalker26 folder together.");
        process = Process.Start(new ProcessStartInfo(runtime, "\"" + Path.Combine(app,"DOC.EXE") + "\"") {
            WorkingDirectory=app, UseShellExecute=false, CreateNoWindow=true, WindowStyle=ProcessWindowStyle.Hidden
        });
        for (int n=0;n<150;n++) {
            if(process.HasExited) throw new IOException("The original speech engine exited. Try restarting the voice engine.");
            uint target=(uint)process.Id;
            EnumWindows(delegate(IntPtr h, IntPtr unused) { uint pid; GetWindowThreadProcessId(h,out pid);
                if(pid==target && GetDlgItem(h,4026)!=IntPtr.Zero && GetDlgItem(h,4023)!=IntPtr.Zero) { window=h; return false; } return true;
            },IntPtr.Zero);
            if(window!=IntPtr.Zero) return;
            await Task.Delay(100);
        }
        Dispose(); throw new TimeoutException("The original speech engine did not become ready within 15 seconds.");
    }
    public async Task Speak(string text) {
        if(string.IsNullOrWhiteSpace(text)) return;
        if(text.Length>4000) throw new ArgumentException("Please keep each phrase below 4,000 characters.");
        await Ready();
        IntPtr result;
        if(SendMessageTimeout(GetDlgItem(window,4026),0x000C,IntPtr.Zero,text,2,2500,out result)==IntPtr.Zero)
            throw new IOException("The speech engine is busy or not responding. Use Stop / restart voice.");
        if(!PostMessage(GetDlgItem(window,4023),0x00F5,IntPtr.Zero,IntPtr.Zero)) throw new IOException("Could not start speech.");
    }
    public async Task ShowControls() { await Ready(); ShowWindow(window,5); SetForegroundWindow(window); }
    public void Dispose() {
        window=IntPtr.Zero;
        if(process==null) return;
        try { if(!process.HasExited) process.Kill(); } catch(InvalidOperationException) {} finally { process.Dispose(); process=null; }
    }
}

sealed class MainForm : Form {
    readonly string root=AppDomain.CurrentDomain.BaseDirectory;
    readonly JavaScriptSerializer json=new JavaScriptSerializer();
    readonly OriginalVoice voice;
    readonly Label status=new Label();
    readonly TextBox composer=new TextBox{ Multiline=true, ScrollBars=ScrollBars.Vertical, MaxLength=4000 };

    readonly List<TextBox> quickBoxes=new List<TextBox>();
    readonly List<Button> customButtons=new List<Button>();
    readonly Random random=new Random();
    Catalog catalog;
    Preferences prefs;
    readonly string settings;
    bool busy;
    bool closing;

    // Classic palette (Windows 95 "Button" gray).
    static readonly Color Face = Color.FromArgb(192,192,192);
    static readonly Color BoxBack = Color.Black;
    static readonly Font UI = new Font("Microsoft Sans Serif",8f);

    public MainForm() {
        Text="Shit talker 1.2   by: jaundice     http://members.aol.com/meatsloth";
        AutoScaleDimensions=new SizeF(96,96); AutoScaleMode=AutoScaleMode.Dpi;
        ClientSize=new Size(800,700); FormBorderStyle=FormBorderStyle.FixedSingle; MaximizeBox=false;
        StartPosition=FormStartPosition.CenterScreen; Font=UI; BackColor=Face;
        voice=new OriginalVoice(root);
        settings=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"ShitTalker26","settings.json");
        catalog=json.Deserialize<Catalog>(File.ReadAllText(Path.Combine(root,"phrases.json")));
        prefs=LoadPreferences();

        // ---- Menu (pipe-delimited, like the original) ----
        var menu=new MenuStrip{ Dock=DockStyle.Top, BackColor=Face, Font=UI, Renderer=new ToolStripSystemRenderer(), GripStyle=ToolStripGripStyle.Hidden };
        var about=new ToolStripMenuItem("About |");about.Click+=(s,e)=>MessageBox.Show(this,"Shit-Talker 1.2 by jaundice\nOriginal SoftVoice / Willow Pond speech engine\nWindows frontend with WineVDM.","About ShitTalker");menu.Items.Add(about);
        var options=new ToolStripMenuItem("Options |");options.DropDownItems.Add("Voice settings",null,async(s,e)=>await Run(()=>voice.ShowControls()));options.DropDownItems.Add("Customize buttons",null,(s,e)=>EditCustom(0));menu.Items.Add(options);
        var restart=new ToolStripMenuItem("Restart DocTalker |");restart.Click+=async(s,e)=>{if(busy)return;voice.Dispose();await Run(async()=>{await voice.Ready();status.Text="DocTalker restarted.";});};menu.Items.Add(restart);
        var quit=new ToolStripMenuItem("Quit Shit-Talker");quit.Click+=(s,e)=>Close();menu.Items.Add(quit);Controls.Add(menu);MainMenuStrip=menu;

        // ---- Top strip: greeting + caller fields, jam radar, exit ----
        AddButton("Hi, can I talk to",8,30,104,26,async()=>await Say("Hi, can I talk to "+nameBox.Text+" please?"));
        nameBox.SetBounds(114,30,150,26);nameBox.AccessibleName="Name to ask for";Add(nameBox);
        AddButton("please?",266,30,70,26,async()=>await Say("Hi, can I talk to "+nameBox.Text+" please?"));
        AddButton("This is / I'm",344,30,95,26,async()=>await Say("This is "+callerBox.Text));
        callerBox.SetBounds(441,30,150,26);callerBox.AccessibleName="Caller name";Add(callerBox);
        AddButton("Jam radar!",599,30,104,26,async()=>{composer.Text=catalog.random[random.Next(catalog.random.Count)];await Say(composer.Text);});
        AddButton("Exit",705,30,87,26,async()=>{Close();});

        // ---- Left column: Questions grid + question list ----
        AddFrame("Questions:",8,62,204,94);
        string[] qRow1={"Who?","Where?","When?","Well?"};string[] qRow2={"What?","Why?","How?","Now?"};
        for(int c=0;c<4;c++){AddButton(qRow1[c],16+c*49,84,47,30,async()=>{composer.Text=qRow1[c];await Say(qRow1[c]);});AddButton(qRow2[c],16+c*49,116,47,30,async()=>{composer.Text=qRow2[c];await Say(qRow2[c]);});}
        string[] questions={"Hello, who is this?","Hello..are you still there?","Do you know what time it is?","Do you have any dogs?","Do you have any children?","Do you have bikes?","Don't you remember me?","Do you dance?","Can I come over?","Can I talk to someone else?","Are you busy tonight?","Can we meet?","Can I ask you a question?","About how long does that take?","Will you be there?","Can i speak with a manager?","What time are you open until?","Is that OK?","Is *random name* there?"};
        for(int i=0;i<questions.Length;i++){int y=160+i*20;AddButton(questions[i],16,y,193,18,async()=>{composer.Text=questions[i];await Say(questions[i]);});}

        // ---- Middle column: Statements/responses grid + statements ----
        AddFrame("Statements/responses:",224,62,396,94);
        GridRow(84,new[]{"Yes","No","I don't know","Hello"},new[]{232,328,424,520},new[]{95,95,95,92});
        GridRow(102,new[]{"OK","I think so.","Goodbye"},new[]{232,359,486},new[]{126,126,126});
        GridRow(120,new[]{"Maybe","That is nice.","Thank you"},new[]{232,359,486},new[]{126,126,126});
        GridRow(138,new[]{"I will.","Wow, cool.","You're welcome"},new[]{232,359,486},new[]{126,126,126});
        string[] stmtL={"I just want to talk.","I am confused","I will be over soon.","I need to talk to you.","i have a cold","I have about 6 myself.","Why not?"};
        string[] stmtR={"Please calm down.","Please do not shout.","Please don't do that.","Please say something.","My car is broken.","What did you call me?","What did you say?"};
        for(int i=0;i<7;i++){int y=160+i*20;AddButton(stmtL[i],232,y,176,18,async()=>{composer.Text=stmtL[i];await Say(stmtL[i]);});AddButton(stmtR[i],416,y,196,18,async()=>{composer.Text=stmtR[i];await Say(stmtR[i]);});}
        string[] stmtFull={"I have another question.","Like to do something this weekend?","Oh it is just a figure of speech.","I was wondering if you could help me.","I will call back tomorrow.","I'm returning your phone call.","Haa ha haaaa. that is funny","Robots are very strong.","I'm selling robot insurance.","Send me some parts.","There is a reason for all of this.","I'm not joking around anymore."};
        for(int i=0;i<stmtFull.Length;i++){int y=302+i*20;AddButton(stmtFull[i],232,y,380,18,async()=>{composer.Text=stmtFull[i];await Say(stmtFull[i]);});}

        // ---- Right column: This box + Quick Boxes ----
        AddFrame("This:",620,62,172,184);
        string[] thisBtns={"Fuck you!","Shut up.","Asshole","Eat my shit.","Go to hell.","Monkey face","So what?","Random Insult","Sicko noise"};
        for(int i=0;i<thisBtns.Length;i++){int y=84+i*17;var label=thisBtns[i];AddButton(label,628,y,156,16,async()=>{string phrase=label=="Random Insult"?Generators.Insult(catalog,random):label=="Sicko noise"?Generators.SickoNoise(catalog,random):label;composer.Text=phrase;await Say(phrase);});}

        AddFrame("Quick Boxes:",620,250,172,432);
        for(int i=0;i<5;i++){int y=270+i*84;var box=i==0?composer:new TextBox();box.Multiline=true;box.ScrollBars=ScrollBars.Vertical;box.MaxLength=4000;box.BorderStyle=BorderStyle.Fixed3D;box.BackColor=BoxBack;box.ForeColor=Color.White;box.Text=prefs.boxes[i]??"";box.AccessibleName="Quick box "+(i+1);box.SetBounds(628,y,156,52);Add(box);quickBoxes.Add(box);var captured=box;box.KeyDown+=async(s,e)=>{if(e.Control&&e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;await Say(captured.Text);}};AddButton("Say it...",628,y+54,104,20,async()=>await Say(captured.Text));AddButton("Clear",734,y+54,50,20,()=>{captured.Clear();return Task.FromResult(0);});}

        // ---- Custom buttons (v1.2 feature) ----
        AddFrame("Custom Buttons:",8,560,604,120);
        for(int i=0;i<16;i++){int index=i;var b=AddButton(CustomLabel(index),16+(i%4)*149,578+(i/4)*20,148,18,async()=>{if(string.IsNullOrWhiteSpace(prefs.buttons[index]))EditCustom(index);else await Say(prefs.buttons[index]);});var ctx=new ContextMenuStrip();ctx.Items.Add("Customize this button",null,(s,e)=>EditCustom(index));b.ContextMenuStrip=ctx;customButtons.Add(b);}

        status.SetBounds(8,684,784,12);status.BorderStyle=BorderStyle.Fixed3D;status.Text="Ready. Right-click a custom button to program it.";Add(status);
        FormClosing+=(s,e)=>{try{SavePreferences();}catch(Exception ex){if(MessageBox.Show(this,"Your settings could not be saved: "+ex.Message+"\nClose anyway?","Save settings",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.No){e.Cancel=true;return;}}closing=true;voice.Dispose();};
    }

    void Add(Control c){Controls.Add(c);}
    void GridRow(int y,string[] labels,int[] xs,int[] ws){for(int i=0;i<labels.Length;i++){int x=xs[i],w=ws[i];AddButton(labels[i],x,y,w,16,async()=>{composer.Text=labels[i];await Say(labels[i]);});}}
    void AddFrame(string title,int x,int y,int w,int h){var f=new GroupBox{Text=title,BackColor=Face};f.SetBounds(x,y,w,h);Add(f);}

    Button MakeButton(string text,Func<Task> action){var b=new Button{Text=text,FlatStyle=FlatStyle.Flat,FlatAppearance={BorderSize=0},BackColor=Face,ForeColor=Color.Black,Font=UI,UseVisualStyleBackColor=false};bool pressed=false;b.Paint+=(s,e)=>DrawBevel(e.Graphics,b.ClientRectangle,pressed);b.MouseDown+=((System.Windows.Forms.MouseEventArgs s2)=>{pressed=true;b.Invalidate();});b.MouseUp+=((System.Windows.Forms.MouseEventArgs s3)=>{if(pressed){pressed=false;b.Invalidate();}});b.MouseLeave+=((System.Windows.Forms.MouseEventArgs s4)=>{if(pressed){pressed=false;b.Invalidate();}});b.Click+=async(s,e)=>{try{await action();}catch(Exception ex){MessageBox.Show(this,ex.Message,"ShitTalker",MessageBoxButtons.OK,MessageBoxIcon.Error);}};return b;}
    void DrawBevel(Graphics g,Rectangle r,bool pressed){var light=Color.White,dark=Color.FromArgb(96,96,96),mid=Color.FromArgb(128,128,128);using(var pL=new Pen(light))g.DrawLines(pL,new[]{new Point(r.Left,r.Top),new Point(r.Right-1,r.Top),new Point(r.Right-1,r.Bottom-1),new Point(r.Left,r.Bottom-1)});if(!pressed){using(var pD=new Pen(dark))g.DrawLines(pD,new[]{new Point(r.Left+1,r.Top+1),new Point(r.Right-2,r.Top+1),new Point(r.Right-2,r.Bottom-2),new Point(r.Left+1,r.Bottom-2)});}else{using(var pD=new Pen(dark))g.DrawLines(pD,new[]{new Point(r.Left,r.Top),new Point(r.Right-1,r.Top),new Point(r.Right-1,r.Bottom-1),new Point(r.Left,r.Bottom-1)});}}
    Button AddButton(string text,int x,int y,int w,int h,Func<Task> action){var b=MakeButton(text,action);b.SetBounds(x,y,w,h);Add(b);return b;}
    string CustomLabel(int i){return string.IsNullOrWhiteSpace(prefs.buttons[i])?"Button "+(i+1):prefs.buttons[i];}
    void EditCustom(int i){using(var d=new Form{Text="Custom button "+(i+1),Size=new Size(500,250),StartPosition=FormStartPosition.CenterParent,MinimizeBox=false,MaximizeBox=false}){var t=new TextBox{Dock=DockStyle.Fill,Multiline=true,Text=prefs.buttons[i]??"",MaxLength=4000};var save=new Button{Dock=DockStyle.Bottom,Height=40,Text="Save",DialogResult=DialogResult.OK};d.Controls.Add(t);d.Controls.Add(save);d.AcceptButton=save;if(d.ShowDialog(this)==DialogResult.OK){prefs.buttons[i]=t.Text;customButtons[i].Text=CustomLabel(i);}}}
    async Task Run(Func<Task> action) {if(busy||closing)return;busy=true;try{await action();}catch(Exception ex){status.Text="Voice error — try Stop / restart voice.";MessageBox.Show(this,ex.Message,"Original voice",MessageBoxButtons.OK,MessageBoxIcon.Error);}finally{busy=false;if(closing)voice.Dispose();}}
    async Task Say(string text) {await Run(async()=>{status.Text="Sending to original SoftVoice engine…";await voice.Speak(text);status.Text="Sent to original voice. Use Stop / restart voice to interrupt.";});}

    readonly TextBox nameBox=new TextBox{ BackColor=BoxBack, ForeColor=Color.White };
    readonly TextBox callerBox=new TextBox{ BackColor=BoxBack, ForeColor=Color.White };

    Preferences LoadPreferences(){if(File.Exists(settings)){try{var p=json.Deserialize<Preferences>(File.ReadAllText(settings));if(p!=null&&p.boxes!=null&&p.boxes.Length==5&&p.buttons!=null&&p.buttons.Length==16)return p;}catch{}}var result=new Preferences();string section="";foreach(var line in File.ReadAllLines(Path.Combine(root,"app","prog.ini"))){if(line.StartsWith("["))section=line.Trim('[',']');else if(line.StartsWith("text=")){int n;if(section.StartsWith("text")&&int.TryParse(section.Substring(4),out n)&&n>=1&&n<=5)result.boxes[n-1]=line.Substring(5);if(section.StartsWith("but")&&int.TryParse(section.Substring(3),out n)&&n>=1&&n<=16)result.buttons[n-1]=line.Substring(5);}}return result;}
    void SavePreferences(){for(int i=0;i<5;i++)prefs.boxes[i]=quickBoxes[i].Text;Directory.CreateDirectory(Path.GetDirectoryName(settings));var tmp=settings+".tmp";File.WriteAllText(tmp,json.Serialize(prefs),Encoding.UTF8);if(File.Exists(settings))File.Replace(tmp,settings,settings+".bak");else File.Move(tmp,settings);}
}

static class Program {
    [STAThread] static void Main(){Application.SetCompatibleTextRenderingDefault(false);try{Application.Run(new MainForm());}catch(Exception ex){MessageBox.Show(ex.ToString(),"ShitTalker could not start");}}
}
